package com.arcsoft.arcfacedemo.common;

public class Constants {
    public static final String APP_ID = "官网申请的APP_ID";
    public static final String SDK_KEY = "官网申请的SDK_KEY";
}
